import requests
from bs4 import BeautifulSoup
import csv
import os

def scrape_article_titles_to_csv(url, csv_file):
    response = requests.get(url)

    soup = BeautifulSoup(response.content,'html.parser')
    titles = soup.find_all('h2')

    with open(csv_file, mode='w', newline='', encoding = 'utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['Title'])
        for title in titles:
            writer.writerow([title.get_text().strip()])
        csv_file_path = os.path.abspath(csv_file)
        print(f"The CSV file has been created at: {csv_file_path}")
url = 'https://www.bbc.com/'
csv_file = 'news_headlines.csv'
scrape_article_titles_to_csv(url, csv_file)