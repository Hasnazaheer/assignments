import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import csv
import os
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
}

def scrape_data(url):
    req = requests.get(url, headers=headers)
    soup = BeautifulSoup(req.content, 'html.parser')
    
    # Scrape the title
    title_element = soup.find('h1', class_="Title")
    title = title_element.text.strip() if title_element else "N/A"

    # Scrape ratings
    rating_list = soup.find_all('span', class_='post-ratings')
    ratings = [rating.text.strip() for rating in rating_list]
    ratings_str = ', '.join(ratings)

    # Scrape genres
    genre_list = soup.find_all('li', class_='AAIco-adjust')
    if genre_list:
        # Get the first <li> element
        first_genre = genre_list[0]
        
        # Find all <a> tags within the first <li> element
        a_tags = first_genre.find_all('a')
        
        # Accumulate the text of each <a> tag in a single string
        genres = ", ".join(a_tag.text.strip() for a_tag in a_tags)
    else:
        genres = "N/A"

    # Return collected data as a dictionary
    meta_paragraphs = soup.find_all('p', class_='meta')

# Iterate over each <p> tag
    for meta in meta_paragraphs:
    # Find all <a> tags within the <p> tag
        a_tags = meta.find_all('a')
    
    # Extract and print the text of each <a> tag
        for a_tag in a_tags:
            year = a_tag.text.strip()
    return {
        'Title': title,
        'Ratings': ratings_str,
        'Genres': genres,
        'Year':year
    }

# Main URL to scrape
url = "https://fmovie.so/featured-movies/"

# Send a GET request to the main webpage
response = requests.get(url, headers=headers)
soup = BeautifulSoup(response.content, 'html.parser')

# Find all <ul> elements with class 'MovieList Rows AX A06 B04 C03 E20'
ul_elements = soup.find_all('ul', class_="MovieList Rows AX A06 B04 C03 E20")

# List to store URLs
links = []

# Iterate over each <ul> element
for ul in ul_elements:
    # Find all <a> tags within the <ul>
    a_tags = ul.find_all('a')
    
    # Extract the href attribute from each <a> tag and convert to absolute URL
    for a_tag in a_tags:
        href = a_tag.get('href')
        if href:
            absolute_url = urljoin(url, href)
            links.append(absolute_url)

# List to store all scraped data
data = []

# Scrape data for each collected link
for link in links:
    scraped_data = scrape_data(link)
    data.append(scraped_data)

# Write the collected data to a CSV file
csv_file = 'movies.csv'
with open(csv_file, 'w', newline='', encoding='utf-8') as file:
    writer = csv.DictWriter(file, fieldnames=['Title', 'Ratings', 'Genres','Year'])
    writer.writeheader()
    writer.writerows(data)

print(f"Data successfully written to {csv_file}")
csv_file_path = os.path.abspath(csv_file)
print(f"The CSV file has been created at: {csv_file_path}")