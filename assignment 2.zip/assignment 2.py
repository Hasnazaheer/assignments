import requests
from bs4 import BeautifulSoup
import csv
import os
# URL of the e-commerce website
baseurl = 'https://priceoye.pk/wireless-earbuds/apple'


headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
}

# Send a request to the website
r = requests.get(baseurl, headers=headers)
soup = BeautifulSoup(r.content, 'html.parser')
name_list = soup.find_all('div',class_="p-title bold h5")

price_list = soup.find_all('div',class_="price-box p1")

data =[]
for name,price in zip(name_list,price_list):
    names = name.text.strip()
    prices = price.text.strip()
    data.append([names,prices])

csv_file = 'products.csv'
with open(csv_file, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(['Product Name', 'Price'])  # Write headers
    writer.writerows(data)  # Write all product data
    
    print(f'CSV file "{csv_file}" has been created successfully.')
csv_file_path = os.path.abspath(csv_file)
print(f"The CSV file has been created at: {csv_file_path}")