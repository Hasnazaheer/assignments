import requests
from bs4 import BeautifulSoup
import csv
import os
url = "https://inclusiveschools.org/blog/"

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
}

# Send a request to the website
r = requests.get(url, headers=headers)
soup = BeautifulSoup(r.content, 'html.parser')

title_list = soup.find_all("h3", class_="fl-post-grid-title")

name_list = soup.find_all("span", class_="fl-post-grid-author")

anchor_tags = soup.find_all('a',class_="fl-post-grid-more")


links = [a.get('href') for a in anchor_tags if a.get('href')]

#data for csv file
data =[]
for title,link,names in zip(title_list,links,name_list):
    titles = title.text.strip()
    name = names.text.strip()
    data.append([titles,link,name])

#creating csv_file
csv_file = 'blog_posts.csv'
with open(csv_file, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(['Title','URL','Author'])  # Write headers
    writer.writerows(data)  # Write all product data
    
    print(f'CSV file "{csv_file}" has been created successfully.')#checking path of file
csv_file_path = os.path.abspath(csv_file)
print(f"The CSV file has been created at: {csv_file_path}")